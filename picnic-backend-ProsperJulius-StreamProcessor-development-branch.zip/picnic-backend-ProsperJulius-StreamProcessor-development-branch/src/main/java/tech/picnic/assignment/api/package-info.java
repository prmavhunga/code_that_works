/**
 * The assignment's external API.
 *
 * <p><strong>Important:</strong> do not touch any files inside this package! Don't move, rename or
 * otherwise modify any of its contents.
 */
package tech.picnic.assignment.api;
