/**
 * The assignment's implementation; to be written by the candidate.
 *
 * <p><strong>Important:</strong> you can make any changes you want in this package, and create
 * subpackages as desired. There is just one rule: make sure that your implementation contains
 * precisely one {@link java.util.ServiceLoader service-loadable} {@link
 * tech.picnic.assignment.api.StreamProcessor}!
 */
package tech.picnic.assignment.impl;
